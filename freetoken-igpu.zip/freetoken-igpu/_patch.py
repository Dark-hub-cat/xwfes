import io

def patch(path, pairs):
    s = io.open(path, encoding='utf8').read()
    for a, b in pairs:
        if a not in s:
            print('MISS', path, repr(a[:60]))
        s = s.replace(a, b)
    io.open(path, 'w', encoding='utf8', newline='').write(s)
    print('patched', path)

patch('include/ft/quant.h', [
    ('std::min<int64_t>(QK, n - base)',
     'std::min<int64_t>((int64_t)QK, n - base)'),
    ('(n + QK - 1) / QK',
     '((n + (int64_t)QK - 1) / (int64_t)QK)'),
    ('int64_t base = b * QK;',
     'int64_t base = b * (int64_t)QK;'),
    ('const int64_t startb = off_elems / QK;',
     'const int64_t startb = off_elems / (int64_t)QK;'),
    ('const int64_t endb = (off_elems + n - 1) / QK;',
     'const int64_t endb = ((int64_t)(off_elems + n) - 1) / (int64_t)QK;'),
    ('int64_t lo = std::max(off_elems, b * (int64_t)QK);',
     'int64_t lo = std::max((int64_t)off_elems, b * (int64_t)QK);'),
    ('int64_t hi = std::min(off_elems + n, (b + 1) * (int64_t)QK);',
     'int64_t hi = std::min((int64_t)(off_elems + n), (b + 1) * (int64_t)QK);'),
])

patch('src/graph.cpp', [
    ('''    std::transform(a.begin(), a.end(), a.begin(), ::tolower);
    c.rope_neox =''',
     '''    std::string al = a;
    std::transform(al.begin(), al.end(), al.begin(), ::tolower);
    a = al;
    c.rope_neox ='''),
])

patch('src/gguf.cpp', [
    ('''            case T_F16: {
                uint16_t h;
                std::memcpy(&h, v.arr_raw.data() + i * 2, 2);
                out[i] = half_to_float(h);
                break;
            }
''', ''),
])

patch('include/ft/engine.h', [
    ('struct RunStats {',
     'struct RunStats {\n    StreamerStats streamer{};'),
])
