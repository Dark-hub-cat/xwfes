# Empty dependencies file for ftcore.
# This may be replaced when dependencies are built.
