
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/closecode/Token-vibe/freetoken-igpu/src/cpu_backend.cpp" "CMakeFiles/ftcore.dir/src/cpu_backend.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/cpu_backend.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/engine.cpp" "CMakeFiles/ftcore.dir/src/engine.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/engine.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/gguf.cpp" "CMakeFiles/ftcore.dir/src/gguf.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/gguf.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/graph.cpp" "CMakeFiles/ftcore.dir/src/graph.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/graph.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/spec.cpp" "CMakeFiles/ftcore.dir/src/spec.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/spec.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/tokenizer.cpp" "CMakeFiles/ftcore.dir/src/tokenizer.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/tokenizer.cpp.obj.d"
  "C:/closecode/Token-vibe/freetoken-igpu/src/vulkan_backend.cpp" "CMakeFiles/ftcore.dir/src/vulkan_backend.cpp.obj" "gcc" "CMakeFiles/ftcore.dir/src/vulkan_backend.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
