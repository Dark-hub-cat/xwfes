file(REMOVE_RECURSE
  "CMakeFiles/ftcore.dir/src/cpu_backend.cpp.obj"
  "CMakeFiles/ftcore.dir/src/cpu_backend.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/engine.cpp.obj"
  "CMakeFiles/ftcore.dir/src/engine.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/gguf.cpp.obj"
  "CMakeFiles/ftcore.dir/src/gguf.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/graph.cpp.obj"
  "CMakeFiles/ftcore.dir/src/graph.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/spec.cpp.obj"
  "CMakeFiles/ftcore.dir/src/spec.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/tokenizer.cpp.obj"
  "CMakeFiles/ftcore.dir/src/tokenizer.cpp.obj.d"
  "CMakeFiles/ftcore.dir/src/vulkan_backend.cpp.obj"
  "CMakeFiles/ftcore.dir/src/vulkan_backend.cpp.obj.d"
  "libftcore.a"
  "libftcore.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ftcore.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
