file(REMOVE_RECURSE
  "libftcore.a"
)
