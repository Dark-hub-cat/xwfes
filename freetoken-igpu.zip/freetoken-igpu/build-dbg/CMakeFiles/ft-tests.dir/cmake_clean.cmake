file(REMOVE_RECURSE
  "CMakeFiles/ft-tests.dir/src/tests/test_core.cpp.obj"
  "CMakeFiles/ft-tests.dir/src/tests/test_core.cpp.obj.d"
  "ft-tests.exe"
  "ft-tests.exe.manifest"
  "ft-tests.pdb"
  "libft-tests.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ft-tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
