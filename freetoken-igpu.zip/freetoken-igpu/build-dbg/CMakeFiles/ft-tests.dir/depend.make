# Empty dependencies file for ft-tests.
# This may be replaced when dependencies are built.
