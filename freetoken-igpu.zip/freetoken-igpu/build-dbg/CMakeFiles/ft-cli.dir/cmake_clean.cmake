file(REMOVE_RECURSE
  "CMakeFiles/ft-cli.dir/src/main.cpp.obj"
  "CMakeFiles/ft-cli.dir/src/main.cpp.obj.d"
  "ft-cli.exe"
  "ft-cli.exe.manifest"
  "ft-cli.pdb"
  "libft-cli.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ft-cli.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
