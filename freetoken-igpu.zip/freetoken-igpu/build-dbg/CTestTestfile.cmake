# CMake generated Testfile for 
# Source directory: C:/closecode/Token-vibe/freetoken-igpu
# Build directory: C:/closecode/Token-vibe/freetoken-igpu/build-dbg
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(core "C:/closecode/Token-vibe/freetoken-igpu/build-dbg/ft-tests.exe")
set_tests_properties(core PROPERTIES  _BACKTRACE_TRIPLES "C:/closecode/Token-vibe/freetoken-igpu/CMakeLists.txt;45;add_test;C:/closecode/Token-vibe/freetoken-igpu/CMakeLists.txt;0;")
